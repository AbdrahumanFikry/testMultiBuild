package com.example.test_multi_build

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
